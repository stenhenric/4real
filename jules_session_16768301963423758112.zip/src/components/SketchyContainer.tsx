import React, { useEffect, useRef, useMemo } from 'react';
import rough from 'roughjs';
import { cn } from '../lib/utils';

interface SketchyContainerProps {
  children: React.ReactNode;
  className?: string;
  fill?: string;
  fillStyle?: 'hachure' | 'solid' | 'zigzag' | 'cross-hatch' | 'dots' | 'dashed';
  stroke?: string;
  strokeWidth?: number;
  roughness?: number;
}

export const SketchyContainer: React.FC<SketchyContainerProps> = ({ 
  children, 
  className,
  fill = 'transparent',
  fillStyle = 'hachure',
  stroke = '#1a1a1a',
  strokeWidth = 2,
  roughness = 1.5
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const seed = useMemo(() => Math.floor(Math.random() * 10000), []);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const draw = (width: number, height: number) => {
      if (width === 0 || height === 0) return;
      
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, width, height);
        const rc = rough.canvas(canvas);
        rc.rectangle(5, 5, width - 10, height - 10, {
          stroke,
          strokeWidth,
          roughness,
          fill,
          fillStyle,
          fillWeight: 1,
          hachureGap: 6,
          seed
        });
      }
    };

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        draw(entry.contentRect.width, entry.contentRect.height);
      }
    });

    resizeObserver.observe(container);

    return () => resizeObserver.disconnect();
  }, [stroke, strokeWidth, roughness, fill, fillStyle, seed]);

  return (
    <div ref={containerRef} className={cn("relative p-4", className)}>
      <canvas 
        ref={canvasRef} 
        className="absolute top-0 left-0 pointer-events-none z-0"
      />
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
};
