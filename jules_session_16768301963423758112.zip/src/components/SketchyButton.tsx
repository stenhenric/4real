import React, { useEffect, useRef, useState, useMemo } from 'react';
import rough from 'roughjs';
import { cn } from '../lib/utils';

interface SketchyButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  fill?: string;
  stroke?: string;
  activeColor?: string;
}

export const SketchyButton: React.FC<SketchyButtonProps> = ({ 
  children, 
  className,
  fill = 'transparent',
  stroke = '#1a1a1a',
  activeColor = '#e5e7eb',
  ...props 
}) => {
  const containerRef = useRef<HTMLButtonElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hovered, setHovered] = useState(false);

  const seed = useMemo(() => Math.floor(Math.random() * 10000), []);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const draw = (width: number, height: number) => {
      if (width === 0 || height === 0) return;
      
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, width, height);
        const rc = rough.canvas(canvas);
        rc.rectangle(4, 4, width - 8, height - 8, {
          stroke,
          strokeWidth: 2,
          roughness: 1.2,
          fill: hovered ? activeColor : fill,
          fillStyle: 'hachure',
          hachureGap: 8,
          seed
        });
      }
    };

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        draw(entry.contentRect.width, entry.contentRect.height);
      }
    });

    resizeObserver.observe(container);

    return () => resizeObserver.disconnect();
  }, [hovered, fill, stroke, activeColor, seed]);

  return (
    <button
      ref={containerRef}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={cn(
        "relative px-6 py-2 font-bold transition-transform active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink-blue disabled:opacity-50 disabled:cursor-not-allowed",
        className
      )}
      {...props}
    >
      <canvas 
        ref={canvasRef} 
        className="absolute top-0 left-0 pointer-events-none z-0"
      />
      <span className="relative z-10">{children}</span>
    </button>
  );
};
