const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on('console', msg => console.log('BROWSER CONSOLE:', msg.text()));
  page.on('pageerror', err => console.log('BROWSER ERROR:', err.message));
  await page.goto('http://localhost:5173/auth');
  await page.waitForLoadState('networkidle');
  console.log("Current URL:", page.url());
  
  const isLoginMode = await page.locator('button:has-text("Enter Notebook")').isVisible();
  console.log("Is Login Mode:", isLoginMode);
  
  await page.fill('input[id="auth-username"]', 'henricstenson');
  await page.fill('input[id="auth-password"]', 'password123');
  await page.click('button:has-text("Enter Notebook")');
  
  await page.waitForTimeout(2000);
  console.log("URL after login:", page.url());
  
  await browser.close();
})();
