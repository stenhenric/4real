import { defineConfig } from '@playwright/test' 
 
export default defineConfig({ 
  testDir: './render-audit', 
  outputDir: './render-audit/output', 
  use: { 
    baseURL: 'http://localhost:5173', 
    screenshot: 'on', 
    video: 'retain-on-failure', 
    trace: 'retain-on-failure', 
    actionTimeout: 10000, 
  }, 
  projects: [ 
    { 
      name: 'desktop', 
      use: { viewport: { width: 1440, height: 900 } }, 
    }, 
    { 
      name: 'mobile', 
      use: { viewport: { width: 375, height: 667 } }, 
    }, 
  ], 
}) 
