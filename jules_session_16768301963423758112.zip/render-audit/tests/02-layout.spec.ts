import { test, expect } from '@playwright/test' 
import { loginUser } from '../helpers/auth' 
import { snapCanvas } from '../helpers/canvas' 
 
test.describe('Layout Rendering', () => { 

  const getProfileUrl = async (page) => {
    await loginUser(page);
    await page.goto('/dashboard');
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('text=Top Sketchers');
    // Click the first user in the leaderboard to go to a valid profile
    const profileLink = page.locator('a[href^="/profile/"]').first();
    const href = await profileLink.getAttribute('href');
    return href || '/';
  }

  test('auth — no horizontal overflow', async ({ page }) => {
    await page.goto('/auth');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await snapCanvas(page, `layout-overflow-auth`);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
    expect(overflow).toBe(false);
  });

  test('dashboard — no horizontal overflow', async ({ page }) => {
    await loginUser(page);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await snapCanvas(page, `layout-overflow-dashboard`);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
    expect(overflow).toBe(false);
  });

  test('bank — no horizontal overflow', async ({ page }) => {
    await loginUser(page);
    await page.goto('/bank');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await snapCanvas(page, `layout-overflow-bank`);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
    expect(overflow).toBe(false);
  });

  test('profile — no horizontal overflow', async ({ page }) => {
    const profileUrl = await getProfileUrl(page);
    await page.goto(profileUrl);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await snapCanvas(page, `layout-overflow-profile`);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
    expect(overflow).toBe(false);
  });

  const checkZeroHeight = async (page, name) => {
    const collapsed = await page.evaluate(() => { 
        return Array.from( 
          document.querySelectorAll( 
            'main, section, article, ' + 
            '[class*="container"], [class*="card"], ' + 
            '[class*="view"], [class*="wrapper"]' 
          ) 
        ) 
        .filter(el => { 
          const rect = el.getBoundingClientRect() 
          return rect.width > 100 && rect.height === 0 
        }) 
        .map(el => ({ 
          tag: el.tagName, 
          class: el.className.slice(0, 60), 
        })) 
      }) 
       
      if (collapsed.length > 0) { 
        await snapCanvas(page,  
          `COLLAPSED-CONTAINER-${name}` 
        ) 
      } 
       
      expect(collapsed, 
        `Zero-height containers on ${name}: ` + 
        JSON.stringify(collapsed) 
      ).toHaveLength(0) 
  }

  test('auth — no zero-height containers', async ({ page }) => {
    await page.goto('/auth');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkZeroHeight(page, 'auth');
  });

  test('dashboard — no zero-height containers', async ({ page }) => {
    await loginUser(page);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkZeroHeight(page, 'dashboard');
  });

  test('bank — no zero-height containers', async ({ page }) => {
    await loginUser(page);
    await page.goto('/bank');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkZeroHeight(page, 'bank');
  });

  test('profile — no zero-height containers', async ({ page }) => {
    const profileUrl = await getProfileUrl(page);
    await page.goto(profileUrl);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkZeroHeight(page, 'profile');
  });


  const checkNavbarOverlap = async (page, name) => {
    const navbarHeight = await page.evaluate(() => { 
        const nav = document.querySelector( 
          'nav, header, [class*="navbar"], [class*="nav-"]' 
        ) 
        if (!nav) return 0 
        const styles = window.getComputedStyle(nav) 
        if (styles.position === 'fixed' ||  
            styles.position === 'sticky') { 
          return nav.getBoundingClientRect().height 
        } 
        return 0 
      }) 
       
      if (navbarHeight > 0) { 
        const topContent = await page.evaluate((navH) => { 
          const main = document.querySelector( 
            'main, [class*="main"], [class*="content"]' 
          ) 
          if (!main) return null 
          const rect = main.getBoundingClientRect() 
          return { 
            top: rect.top, 
            navbarHeight: navH, 
            hidden: rect.top < navH - 5, 
          } 
        }, navbarHeight) 
         
        if (topContent?.hidden) { 
          await snapCanvas(page,  
            `NAVBAR-OVERLAP-${name}` 
          ) 
          expect(topContent.hidden, 
            `Content starts at ${topContent.top}px from top ` + 
            `but navbar is ${navbarHeight}px tall. ` + 
            `Content is hidden behind fixed navbar.` 
          ).toBe(false) 
        } 
      } 
  }

  test('auth — no content hidden behind navbar', async ({ page }) => {
    await page.goto('/auth');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkNavbarOverlap(page, 'auth');
  });

  test('dashboard — no content hidden behind navbar', async ({ page }) => {
    await loginUser(page);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkNavbarOverlap(page, 'dashboard');
  });

  test('bank — no content hidden behind navbar', async ({ page }) => {
    await loginUser(page);
    await page.goto('/bank');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkNavbarOverlap(page, 'bank');
  });

  test('profile — no content hidden behind navbar', async ({ page }) => {
    const profileUrl = await getProfileUrl(page);
    await page.goto(profileUrl);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(400);
    await checkNavbarOverlap(page, 'profile');
  });


  const checkLoadingAndErrorStates = async (page, name, url, shouldLogin) => {
    if (shouldLogin) await loginUser(page);
    await page.goto(url);
    await snapCanvas(page, `loading-state-${name}`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);
    await snapCanvas(page, `loaded-state-${name}`);

    const hasContent = await page.evaluate(() => { 
        const body = document.body 
        return body.innerText.trim().length > 0 ||  
               body.querySelectorAll('img, canvas, svg').length > 0 
      }) 
       
      expect(hasContent, 
        `${name} appears blank after loading` 
      ).toBe(true) 
  }

  test('auth — loading and error states render', async ({ page }) => {
    await checkLoadingAndErrorStates(page, 'auth', '/auth', false);
  });

  test('dashboard — loading and error states render', async ({ page }) => {
    await checkLoadingAndErrorStates(page, 'dashboard', '/', true);
  });

  test('bank — loading and error states render', async ({ page }) => {
    await checkLoadingAndErrorStates(page, 'bank', '/bank', true);
  });

  test('profile — loading and error states render', async ({ page }) => {
    const profileUrl = await getProfileUrl(page);
    await checkLoadingAndErrorStates(page, 'profile', profileUrl, true);
  });
})
