import { test, expect } from '@playwright/test' 
import { loginUser } from '../helpers/auth' 
import { getAllCanvases, snapCanvas } from '../helpers/canvas' 
 
const MOBILE = { width: 375, height: 667 } 
 
test.describe('Responsive Rendering (Mobile)', () => { 
 
  test.beforeEach(async ({ page }) => { 
    await page.setViewportSize(MOBILE) 
  }) 
 
  const getProfileUrl = async (page) => {
    await loginUser(page);
    await page.goto('/dashboard');
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('text=Top Sketchers');
    // Click the first user in the leaderboard to go to a valid profile
    const profileLink = page.locator('a[href^="/profile/"]').first();
    const href = await profileLink.getAttribute('href');
    return href || '/';
  }

  test(`auth — no overflow at 375px`, async ({ page }) => { 
    await page.goto('/auth') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(500) 
     
    await snapCanvas(page, `mobile-auth-375px`) 
     
    const scrollWidth = await page.evaluate( 
      () => document.documentElement.scrollWidth 
    ) 
    const innerWidth = await page.evaluate( 
      () => window.innerWidth 
    ) 
     
    expect(scrollWidth, 
      `Horizontal overflow on mobile auth: ` + 
      `scrollWidth=${scrollWidth} > innerWidth=${innerWidth}` 
    ).toBeLessThanOrEqual(innerWidth + 2) 
  }) 

  test(`dashboard — no overflow at 375px`, async ({ page }) => { 
    await loginUser(page) 
    await page.goto('/') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(500) 
     
    await snapCanvas(page, `mobile-dashboard-375px`) 
     
    const scrollWidth = await page.evaluate( 
      () => document.documentElement.scrollWidth 
    ) 
    const innerWidth = await page.evaluate( 
      () => window.innerWidth 
    ) 
     
    expect(scrollWidth, 
      `Horizontal overflow on mobile dashboard: ` + 
      `scrollWidth=${scrollWidth} > innerWidth=${innerWidth}` 
    ).toBeLessThanOrEqual(innerWidth + 2) 
  }) 

  test(`bank — no overflow at 375px`, async ({ page }) => { 
    await loginUser(page) 
    await page.goto('/bank') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(500) 
     
    await snapCanvas(page, `mobile-bank-375px`) 
     
    const scrollWidth = await page.evaluate( 
      () => document.documentElement.scrollWidth 
    ) 
    const innerWidth = await page.evaluate( 
      () => window.innerWidth 
    ) 
     
    expect(scrollWidth, 
      `Horizontal overflow on mobile bank: ` + 
      `scrollWidth=${scrollWidth} > innerWidth=${innerWidth}` 
    ).toBeLessThanOrEqual(innerWidth + 2) 
  }) 
 
  test('inputs do not trigger iOS zoom (font-size >= 16px)',  
    async ({ page }) => { 
    const screens = ['/auth', '/bank'] 
     
    for (const route of screens) { 
      if (route === '/bank') await loginUser(page);
      await page.goto(route) 
      await page.waitForLoadState('networkidle') 
       
      const zoomRisk = await page.evaluate(() => { 
        return Array.from( 
          document.querySelectorAll('input, textarea, select') 
        ) 
        .filter(el => { 
          const size = parseFloat( 
            window.getComputedStyle(el).fontSize 
          ) 
          return size < 16 &&  
                 (el as HTMLElement).offsetWidth > 0 
        }) 
        .map(el => ({ 
          type: (el as HTMLInputElement).type || 'unknown', 
          placeholder: (el as HTMLInputElement).placeholder, 
          fontSize: window.getComputedStyle(el).fontSize, 
        })) 
      }) 
       
      if (zoomRisk.length > 0) { 
        await snapCanvas(page,  
          `ZOOM-RISK-${route.replace('/', '')}-mobile` 
        ) 
      } 
       
      expect(zoomRisk, 
        `Inputs with font-size < 16px on ${route} ` + 
        `(will trigger iOS zoom): ` + 
        JSON.stringify(zoomRisk) 
      ).toHaveLength(0) 
    } 
  }) 
 
  test('touch targets are at least 44px on mobile',  
    async ({ page }) => { 
    await loginUser(page) 
    await page.goto('/') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(400) 
     
    await snapCanvas(page, 'touch-targets-mobile') 
     
    const smallTargets = await page.evaluate(() => { 
      return Array.from(document.querySelectorAll( 
        'button, a, [role="button"]' 
      )) 
      .filter(el => { 
        const rect = el.getBoundingClientRect() 
        return rect.width > 0 &&  
               (rect.width < 44 || rect.height < 44) 
      }) 
      .map(el => ({ 
        text: (el.textContent ?? '').slice(0, 30).trim(), 
        width: Math.round(el.getBoundingClientRect().width), 
        height: Math.round(el.getBoundingClientRect().height), 
      })) 
    }) 
     
    if (smallTargets.length > 0) { 
      await snapCanvas(page,  
        'SMALL-TOUCH-TARGETS-mobile' 
      ) 
    } 
     
    expect(smallTargets, 
      `Touch targets smaller than 44x44px: ` + 
      JSON.stringify(smallTargets, null, 2) 
    ).toHaveLength(0) 
  }) 
 
  test('canvases render correctly at 375px', async ({ page }) => { 
    await page.goto('/auth') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(600) 
     
    const canvases = await getAllCanvases(page) 
    await snapCanvas(page, 'canvas-mobile-375px') 
     
    for (const c of canvases) { 
      expect(c.isBlank, 
        `Canvas ${c.index} is blank at 375px viewport. ` + 
        `Canvas: ${c.attrWidth}x${c.attrHeight}` 
      ).toBe(false) 
       
      expect(c.attrWidth, 
        `Canvas ${c.index} is wider than mobile viewport: ` + 
        `${c.attrWidth}px > 375px` 
      ).toBeLessThanOrEqual(375) 
    } 
  }) 
})
