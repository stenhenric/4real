import { test, expect } from '@playwright/test' 
import { loginUser } from '../helpers/auth' 
import { snapCanvas } from '../helpers/canvas' 
 
test.describe('React Render Cycle Bugs', () => { 

  const getProfileUrl = async (page) => {
    await loginUser(page);
    await page.goto('/dashboard');
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('text=Top Sketchers');
    // Click the first user in the leaderboard to go to a valid profile
    const profileLink = page.locator('a[href^="/profile/"]').first();
    const href = await profileLink.getAttribute('href');
    return href || '/';
  }

  test('no duplicate API calls on page load (render loop check)',  
    async ({ page }) => { 
    const apiCalls: string[] = [] 
     
    page.on('request', req => { 
      if (req.url().includes('/api/')) { 
        apiCalls.push(`${req.method()} ${new URL(req.url()).pathname}`) 
      } 
    }) 
     
    await loginUser(page) 
    await page.goto('/') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(1500) 
     
    await snapCanvas(page, 'render-cycle-api-calls') 
     
    const counts = apiCalls.reduce((acc, call) => { 
      acc[call] = (acc[call] ?? 0) + 1 
      return acc 
    }, {} as Record<string, number>) 
     
    const runaway = Object.entries(counts) 
      .filter(([_, n]) => n > 3) 
      .map(([call, n]) => `${call} ×${n}`) 
     
    expect(runaway, 
      `Runaway API calls detected (infinite re-render?): ` + 
      runaway.join(', ') 
    ).toHaveLength(0) 
  }) 
 
  test('no console errors on any screen', async ({ page }) => { 
    const errors: string[] = [] 
    page.on('console', msg => { 
      if (msg.type() === 'error') errors.push(msg.text()) 
    }) 
    page.on('pageerror', err => errors.push(err.message)) 
     
    await loginUser(page) 
     
    const profileUrl = await getProfileUrl(page);

    const routes = ['/', '/bank', profileUrl] 
     
    for (const route of routes) { 
      errors.length = 0 
      await page.goto(route) 
      await page.waitForLoadState('networkidle') 
      await page.waitForTimeout(500) 
       
      if (errors.length > 0) { 
        await snapCanvas(page,  
          `CONSOLE-ERROR-${route.replace(/\//g, '')}` 
        ) 
        console.log( 
          `Console errors on ${route}:`, errors 
        ) 
      } 
       
      expect(errors, 
        `Console errors on ${route}:\n` + errors.join('\n') 
      ).toHaveLength(0) 
    } 
  }) 
 
  test('no layout shift after data loads', async ({ page }) => { 
    await loginUser(page) 
    await page.goto('/') 
     
    await snapCanvas(page, 'cls-before-data') 
     
    const before = await page.evaluate(() => 
      Array.from(document.querySelectorAll( 
        'h1, h2, nav, [class*="card"]' 
      )).map(el => ({ 
        cls: el.className.slice(0, 40), 
        top: Math.round(el.getBoundingClientRect().top), 
      })) 
    ) 
     
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(500) 
    await snapCanvas(page, 'cls-after-data') 
     
    const after = await page.evaluate(() => 
      Array.from(document.querySelectorAll( 
        'h1, h2, nav, [class*="card"]' 
      )).map(el => ({ 
        cls: el.className.slice(0, 40), 
        top: Math.round(el.getBoundingClientRect().top), 
      })) 
    ) 
     
    const shifts = before 
      .map((b, i) => { 
        const a = after[i] 
        if (!a) return null 
        const delta = Math.abs(a.top - b.top) 
        return delta > 5  
          ? { element: b.cls, shift: delta }  
          : null 
      }) 
      .filter(Boolean) 
     
    if (shifts.length > 0) { 
      await snapCanvas(page, 'CLS-DETECTED') 
    } 
     
    expect(shifts, 
      `Layout shifts after data load: ` + 
      JSON.stringify(shifts) 
    ).toHaveLength(0) 
  }) 
})
