import { test, expect } from '@playwright/test' 
import { loginUser } from '../helpers/auth' 
import { getAllCanvases, snapCanvas } from '../helpers/canvas' 
 
test.describe('Canvas / rough.js Rendering', () => { 
  test.beforeEach(async ({ page }) => {
    // Wait for the app to be fully initialized and seeded data to be available
    await page.waitForTimeout(1000);
  });

  const getProfileUrl = async (page) => {
    await loginUser(page);
    await page.goto('/dashboard');
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('text=Top Sketchers');
    // Click the first user in the leaderboard to go to a valid profile
    const profileLink = page.locator('a[href^="/profile/"]').first();
    const href = await profileLink.getAttribute('href');
    return href || '/';
  }

  test('auth — no blank canvases', async ({ page }) => {
    await page.goto('/auth');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-blank-check-auth`);
    expect(canvases.length).toBeGreaterThan(0);
    for (const c of canvases) {
      expect(c.isBlank).toBe(false);
      expect(c.attrWidth).toBeGreaterThan(0);
      expect(c.attrHeight).toBeGreaterThan(0);
    }
  });

  test('dashboard — no blank canvases', async ({ page }) => {
    await loginUser(page);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-blank-check-dashboard`);
    expect(canvases.length).toBeGreaterThan(0);
    for (const c of canvases) {
      expect(c.isBlank).toBe(false);
      expect(c.attrWidth).toBeGreaterThan(0);
      expect(c.attrHeight).toBeGreaterThan(0);
    }
  });

  test('bank — no blank canvases', async ({ page }) => {
    await loginUser(page);
    await page.goto('/bank');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-blank-check-bank`);
    expect(canvases.length).toBeGreaterThan(0);
    for (const c of canvases) {
      expect(c.isBlank).toBe(false);
      expect(c.attrWidth).toBeGreaterThan(0);
      expect(c.attrHeight).toBeGreaterThan(0);
    }
  });

  test('profile — no blank canvases', async ({ page }) => {
    const profileUrl = await getProfileUrl(page);
    await page.goto(profileUrl);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-blank-check-profile`);
    expect(canvases.length).toBeGreaterThan(0);
    for (const c of canvases) {
      expect(c.isBlank).toBe(false);
      expect(c.attrWidth).toBeGreaterThan(0);
      expect(c.attrHeight).toBeGreaterThan(0);
    }
  });

  test('auth — canvas size matches container', async ({ page }) => {
    await page.goto('/auth');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-size-mismatch-auth`);
    for (const c of canvases) {
      expect(c.sizeMismatch).toBe(false);
    }
  });

  test('dashboard — canvas size matches container', async ({ page }) => {
    await loginUser(page);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-size-mismatch-dashboard`);
    for (const c of canvases) {
      expect(c.sizeMismatch).toBe(false);
    }
  });

  test('bank — canvas size matches container', async ({ page }) => {
    await loginUser(page);
    await page.goto('/bank');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-size-mismatch-bank`);
    for (const c of canvases) {
      expect(c.sizeMismatch).toBe(false);
    }
  });

  test('profile — canvas size matches container', async ({ page }) => {
    const profileUrl = await getProfileUrl(page);
    await page.goto(profileUrl);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(600);
    const canvases = await getAllCanvases(page);
    await snapCanvas(page, `canvas-size-mismatch-profile`);
    for (const c of canvases) {
      expect(c.sizeMismatch).toBe(false);
    }
  });

  test('canvas does not flicker when typing in input',  
    async ({ page }) => { 
    await page.goto('/auth') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(600) 
     
    const before = await getAllCanvases(page) 
    await snapCanvas(page, 'canvas-flicker-before-typing') 
     
    const input = page.locator( 
      'input[id="auth-username"], input[placeholder*="CoolSketcher42" i]' 
    ).first() 
    await input.fill('testuser') 
    await page.waitForTimeout(200) 
     
    const after = await getAllCanvases(page) 
    await snapCanvas(page, 'canvas-flicker-after-typing') 
     
    expect(after.length, 
      `Canvas count changed from ${before.length} to ` + 
      `${after.length} after typing. ` + 
      `Component may be remounting on state change.` 
    ).toBe(before.length) 
     
    for (const c of after) { 
      expect(c.isBlank, 
        `Canvas ${c.index} went blank after typing. ` + 
        `rough.js is redrawing on every React state update. ` + 
        `Seed is likely Math.random() per render.` 
      ).toBe(false) 
    } 
  }) 
 
  test('canvas survives navigate away and back',  
    async ({ page }) => { 
    await loginUser(page) 
     
    await page.goto('/bank') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(600) 
     
    const firstVisit = await getAllCanvases(page) 
    await snapCanvas(page, 'canvas-nav-first-visit') 
     
    await page.goto('/') 
    await page.waitForLoadState('networkidle') 
     
    await page.goto('/bank') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(600) 
     
    const secondVisit = await getAllCanvases(page) 
    await snapCanvas(page, 'canvas-nav-second-visit') 
     
    expect(secondVisit.length, 
      `Canvas count grew: ${firstVisit.length} → ` + 
      `${secondVisit.length} after re-navigation. ` + 
      `useEffect cleanup is not disconnecting ResizeObserver.` 
    ).toBe(firstVisit.length) 
     
    for (const c of secondVisit) { 
      expect(c.isBlank, 
        `Canvas ${c.index} blank after re-navigation` 
      ).toBe(false) 
    } 
  }) 
 
  test('canvas redraws correctly after viewport resize',  
    async ({ page }) => { 
    await page.goto('/auth') 
    await page.waitForLoadState('networkidle') 
    await page.waitForTimeout(600) 
     
    const desktop = await getAllCanvases(page) 
    await snapCanvas(page, 'canvas-resize-desktop') 
     
    await page.setViewportSize({ width: 375, height: 667 }) 
    await page.waitForTimeout(600) 
     
    const mobile = await getAllCanvases(page) 
    await snapCanvas(page, 'canvas-resize-mobile') 
     
    for (let i = 0; i < mobile.length; i++) { 
      const d = desktop[i] 
      const m = mobile[i] 
      if (!d || !m) continue 
       
      expect(m.isBlank, 
        `Canvas ${i} went blank after resize to 375px. ` + 
        `ResizeObserver may not be attached.` 
      ).toBe(false) 
       
      if (m.displayWidth < d.displayWidth - 10) { 
        expect(m.attrWidth, 
          `Canvas ${i} did not resize: ` + 
          `still ${m.attrWidth}px after viewport shrunk to 375px. ` + 
          `ResizeObserver not updating canvas dimensions.` 
        ).toBeLessThan(d.attrWidth) 
      } 
    } 
  }) 
 
  test('no duplicate canvases inside same component',  
    async ({ page }) => { 
    const screens = ['/auth', '/', '/bank'] 
    await loginUser(page) 
     
    for (const route of screens) { 
      await page.goto(route) 
      await page.waitForLoadState('networkidle') 
      await page.waitForTimeout(600) 
       
      const duplicates = await page.evaluate(() => { 
        const parents = new Map<Element, number>() 
        document.querySelectorAll('canvas').forEach(c => { 
          const p = c.parentElement 
          if (p) parents.set(p, (parents.get(p) ?? 0) + 1) 
        }) 
        const dupes: string[] = [] 
        parents.forEach((count, el) => { 
          if (count > 1) { 
            dupes.push( 
              `${el.tagName}.${el.className} ` + 
              `has ${count} canvas children` 
            ) 
          } 
        }) 
        return dupes 
      }) 
       
      if (duplicates.length > 0) { 
        await snapCanvas(page,  
          `DUPLICATE-CANVAS-${route.replace('/', '')}` 
        ) 
      } 
       
      expect(duplicates, 
        `Duplicate canvases on ${route}: ` +  
        duplicates.join(', ') 
      ).toHaveLength(0) 
    } 
  }) 
})
