import { Page } from '@playwright/test' 
 
export async function loginUser(page: Page) { 
  await page.goto('/auth') 
  await page.waitForLoadState('networkidle') 
   
  const isLoginMode = await page.locator('button', { hasText: 'Enter Notebook' }).isVisible();
  
  if (!isLoginMode) {
      const toggleBtn = page.locator('button', { hasText: 'Log into Existing Sketch' });
      if (await toggleBtn.isVisible()) {
        await toggleBtn.click();
      }
  }

  const usernameInput = page.locator(
    'input[id="auth-username"]'
  ).first();

  const passwordInput = page.locator(
    'input[id="auth-password"]'
  ).first();

  const loginButton = page.locator(
    'button:has-text("Enter Notebook")'
  ).first();
   
  if (await usernameInput.isVisible()) {
      await usernameInput.fill('player1') 
      await passwordInput.fill('password123') 
      await loginButton.click() 
       
      await page.waitForURL(url => !url.pathname.includes('/auth'), { 
        timeout: 10000 
      }) 
  }
}
