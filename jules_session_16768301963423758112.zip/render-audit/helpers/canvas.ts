import { Page } from '@playwright/test' 
 
export async function getAllCanvases(page: Page) { 
  return await page.evaluate(() => { 
    const canvases = Array.from( 
      document.querySelectorAll('canvas') 
    ) 
    return canvases.map((canvas, i) => { 
      const ctx = canvas.getContext('2d') 
      const imageData = ctx?.getImageData( 
        0, 0,  
        Math.max(canvas.width, 1),  
        Math.max(canvas.height, 1) 
      ) 
      const pixels = imageData?.data ?? new Uint8ClampedArray() 
      let hasContent = false 
      for (let j = 3; j < pixels.length; j += 4) { 
        if (pixels[j] > 0) { hasContent = true; break } 
      } 
      const rect = canvas.getBoundingClientRect() 
      return { 
        index: i, 
        attrWidth: canvas.width, 
        attrHeight: canvas.height, 
        displayWidth: Math.round(rect.width), 
        displayHeight: Math.round(rect.height), 
        hasContent, 
        isBlank: !hasContent, 
        sizeMismatch: 
          Math.abs(canvas.width - rect.width) > 2 || 
          Math.abs(canvas.height - rect.height) > 2, 
        parentTag: canvas.parentElement?.tagName, 
        parentClass: canvas.parentElement?.className, 
        zIndex: window.getComputedStyle(canvas).zIndex, 
        position: window.getComputedStyle(canvas).position, 
      } 
    }) 
  }) 
} 
 
export async function snapCanvas( 
  page: Page,  
  name: string 
) { 
  await page.screenshot({ 
    path: `render-audit/output/${name}.png`, 
    fullPage: true, 
    animations: 'disabled', 
  }) 
  return `render-audit/output/${name}.png` 
}
